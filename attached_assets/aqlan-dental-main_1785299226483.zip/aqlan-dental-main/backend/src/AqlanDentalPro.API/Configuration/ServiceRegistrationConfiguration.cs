using AqlanDentalPro.Application.Interfaces.Repositories;
using AqlanDentalPro.Application.Interfaces.Services;
using AqlanDentalPro.Application.Services;
using AqlanDentalPro.Application.Validators;
using AqlanDentalPro.API.Hubs;
using AqlanDentalPro.Infrastructure.Repositories;
using AqlanDentalPro.Infrastructure.Services;
using MessagingService = AqlanDentalPro.Infrastructure.Services.MessagingService;
using PatientPortalService = AqlanDentalPro.Infrastructure.Services.PatientPortalService;
using WhatsAppService = AqlanDentalPro.Infrastructure.Services.WhatsAppService;
using Microsoft.Extensions.DependencyInjection;

namespace AqlanDentalPro.API.Configuration;

/// <summary>
/// Extension method for application service DI registrations.
/// Extracted from Program.cs for cleaner service configuration.
/// </summary>
public static class ServiceRegistrationConfiguration
{
    /// <summary>
    /// Registers all application repositories, services, hosted services, and HTTP clients.
    /// </summary>
    public static void AddApplicationServices(this IServiceCollection services)
    {
        // ── DI — Repositories ────────────────────────────────────────────────────────
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IPatientRepository, PatientRepository>();
        services.AddScoped<IAppointmentRepository, AppointmentRepository>();

        // ── DI — Services ────────────────────────────────────────────────────────────
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<ITokenService, TokenService>();
        services.AddScoped<ICurrentUserService, CurrentUserService>();
        services.AddScoped<IAuditService, AuditService>();
        services.AddScoped<IPatientSettingsReader, PatientSettingsReader>();
        services.AddScoped<IClinicClock, ClinicClock>();
        services.AddScoped<PatientService>();
        services.AddScoped<AppointmentService>();
        services.AddScoped<DashboardService>();
        services.AddScoped<OrthoService>();
        // TD-021 PR A4: FinanceService/IFinanceService retired — the payment cluster
        // lives in PaymentService, supplier payables/credit-note refunds in
        // SupplierRefundService, and the contract orchestrators in ContractService.
        services.AddScoped<IPaymentService, PaymentService>();
        services.AddScoped<IAdvancePaymentAllocationService, AdvancePaymentAllocationService>();
        services.AddScoped<ISupplierRefundService, SupplierRefundService>();
        // TD-021 PR A1: invoice-ledger posting extracted from FinanceService. Self-contained
        // (db + journalEntryService + currentUser + logger only) — first slice of the
        // FinanceService god-service decomposition. See docs/technical-debt/TD-021-god-service-extraction-plan.md.
        services.AddScoped<IInvoiceLedgerService, InvoiceLedgerService>();
        // TD-021 PR A2: read-side finance service extracted from FinanceService. Owns all
        // read-only aggregation queries (statements, summaries, overdue). Shared static
        // helpers (MapPayment, NormalizeCurrency) live in FinanceMappers and are used by
        // both FinanceService (write) and FinanceReadService (read).
        services.AddScoped<IFinanceReadService, FinanceReadService>();
        // TD-021 PR A3+A4: contract service extracted from the former FinanceService. Owns
        // the full contracts cluster: reads, UpdateContract, CreateContract (down payment
        // via IPaymentService), and UpdateContractStatus (cancellation reversals).
        services.AddScoped<IContractService, ContractService>();
        // FIN-SETTINGS: read helper for the finance.* Settings namespace.
        services.AddScoped<FinanceSettingsReader>();
        services.AddScoped<IJournalEntryService, JournalEntryService>();
        services.AddScoped<ITreasuryResolutionService, TreasuryResolutionService>();
        services.AddScoped<GeneralService>();
        services.AddScoped<IMessagingService, MessagingService>();
        services.AddScoped<IPatientAccountLinkingService, PatientAccountLinkingService>();
        services.AddScoped<IPatientPortalMessagingService, PatientPortalMessagingService>();
        services.AddScoped<IRealTimePushService, SignalRPushService>();
        services.AddScoped<CephService>();
        services.AddScoped<PhotoAnalysisService>();
        services.AddScoped<AqlanDentalPro.API.Services.CephReportPdfGenerator>();
        services.AddScoped<AqlanDentalPro.API.Services.PhotoAnalysisReportPdfGenerator>();
        services.AddScoped<AqlanDentalPro.API.Services.OrthoModelAnalysisReportPdfGenerator>();
        services.AddScoped<AqlanDentalPro.API.Services.OrthoCaseSummaryReportPdfGenerator>();
        services.AddScoped<AqlanDentalPro.API.Services.OrthoSurgicalReportPdfGenerator>();
        services.AddScoped<AqlanDentalPro.API.Services.OrthoCasePresentationService>();
        services.AddScoped<AqlanDentalPro.API.Services.OrthoImagePreparationRenderer>();
        services.AddScoped<IPatientPortalService, PatientPortalService>();
        services.AddScoped<IWhatsAppService, WhatsAppService>();
        services.AddScoped<INotificationService, AqlanDentalPro.Infrastructure.Services.NotificationService>();
        // SEQ-13: resolve clinic.timezone once at startup, then serve all date calculations
        // from ClinicTimeProvider's thread-safe cache (no per-request database reads).
        services.AddHostedService<ClinicTimeZoneInitializer>();
        services.AddHostedService<AqlanDentalPro.Infrastructure.Services.OverdueNotificationJob>();
        services.AddHostedService<AqlanDentalPro.Infrastructure.Services.AppointmentReminderJob>();
        services.AddHostedService<AqlanDentalPro.API.Services.AutoBackupJob>();
        services.AddScoped<IBookingRequestService, AqlanDentalPro.Infrastructure.Services.BookingRequestService>();
        services.AddScoped<AqlanDentalPro.Application.Interfaces.Services.ICommissionService, AqlanDentalPro.Infrastructure.Services.CommissionService>();
        services.AddScoped<AqlanDentalPro.Application.Interfaces.Services.IPatientAccessService, AqlanDentalPro.Infrastructure.Services.PatientAccessService>();
        services.AddScoped<ILoginAttemptService, LoginAttemptService>();

        // CLIN-22: Patient-journey read/write services extracted from PatientJourneyController.
        // Concrete classes (no interface) — matches existing DashboardService / OrthoService pattern.
        services.AddScoped<PatientJourneyService>();
        services.AddScoped<CheckoutService>();

        // Sprint 12: READ-side query service extracted from LabOrdersController.
        // Concrete class (no interface) — matches PatientJourneyService / DashboardService pattern.
        services.AddScoped<LabOrderQueryService>();
        // CORE-LAB-001: shared, idempotent supplier-bill/payable/journal linkage for lab
        // orders — used by both create and update so a draft completed later still bills.
        services.AddScoped<LabOrderFinanceSyncService>();
        // READ-side query service extracted from OrthoCasesController (LabOrderQueryService pattern).
        // Concrete class (no interface). Controller keeps permission checks + write endpoints;
        // GET endpoints delegate their EF queries here.
        services.AddScoped<OrthoCaseQueryService>();
        services.AddHttpClient(); // Register IHttpClientFactory for PatientPortalService
        services.AddHttpClient("RemoteClinicalImage", client =>
        {
            client.Timeout = TimeSpan.FromSeconds(20);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("AqlanDentalPro/1.0");
        })
        .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
        {
            AllowAutoRedirect = false,
            AutomaticDecompression = System.Net.DecompressionMethods.All,
        });
        services.AddHttpClient<IRecaptchaService, RecaptchaService>();
        services.AddScoped<IPdfService, PdfService>();
        services.AddScoped<IEmailService, EmailService>();
        services.AddHttpClient("WhatsApp", client =>
        {
            client.Timeout = TimeSpan.FromSeconds(15);
        });
        // Ceph batch C-D — real LLM draft-diagnosis assistant. The orchestrator
        // (CephAiDraftService) resolves a provider from the IAiDraftProvider set
        // (gemini default, anthropic; openai recognized but not implemented).
        // Named client follows the WhatsApp/Sms pattern; 60s because LLM
        // generation is slower than messaging webhooks.
        services.AddScoped<CephAiDraftService>();
        services.AddScoped<CephAiLandmarkDraftService>();
        services.AddScoped<CephAiModelRegistryService>();
        services.AddScoped<OrthoCaseDraftService>();
        services.AddScoped<OrthoSurgicalDraftService>();
        services.AddScoped<AiApiKeyVault>();
        services.AddScoped<IAiDraftProvider, AqlanDentalPro.Infrastructure.Services.Ai.GeminiAiDraftProvider>();
        services.AddScoped<IAiDraftProvider, AqlanDentalPro.Infrastructure.Services.Ai.AnthropicAiDraftProvider>();
        services.AddScoped<ICephLandmarkDraftProvider, AqlanDentalPro.Infrastructure.Services.Ai.GeminiCephLandmarkDraftProvider>();
        services.AddScoped<ICephLandmarkDraftProvider, AqlanDentalPro.Infrastructure.Services.Ai.AnthropicCephLandmarkDraftProvider>();
        services.AddHttpClient(CephAiDraftService.HttpClientName, client =>
        {
            client.Timeout = TimeSpan.FromSeconds(60);
        });
        services.AddScoped<ISmsService, SmsService>();
        services.AddHttpClient("Sms", client =>
        {
            client.Timeout = TimeSpan.FromSeconds(30);
        });

        services.AddHttpContextAccessor();

        // CLIN-01: Register the PatientAccessFilter so controllers can use [ServiceFilter(typeof(PatientAccessFilter))]
        services.AddScoped<AqlanDentalPro.API.Authorization.PatientAccessFilter>();
    }
}
