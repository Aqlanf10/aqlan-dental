using AqlanDentalPro.Application.DTOs.Common;
using AqlanDentalPro.Domain.Entities;
using System.Linq.Expressions;

namespace AqlanDentalPro.Application.Interfaces.Repositories;

public interface IPatientRepository : IGenericRepository<Patient>
{
    Task<PaginatedResponse<Patient>> SearchAsync(string? search, int page, int pageSize, Guid? branchId, string? gender = null, Guid? doctorId = null, string? status = "active", IReadOnlySet<Guid>? allowedPatientIds = null);
    Task<Patient?> GetWithHistoriesAsync(Guid id);
    Task<Patient?> GetWithHistoriesIgnoreFiltersAsync(Guid id);
    Task<Patient?> GetByIdIgnoreFiltersAsync(Guid id);
    Task<Patient?> GetArchivedByIdAsync(Guid id);
    Task<Patient?> FindByNormalizedPhoneAsync(string normalizedPhone, Guid? excludeId = null);
    Task<string> GeneratePatientNumberAsync(string prefix);
    Task<Patient?> FirstOrDefaultAsync(Expression<Func<Patient, bool>> predicate);
    Task<Dictionary<Guid, DateTime?>> GetLastVisitDatesAsync(IEnumerable<Guid> patientIds);
}
