using AqlanDentalPro.Application.DTOs.Ceph;
using FluentValidation;

namespace AqlanDentalPro.Application.Validators;

public sealed class CreateCephAnalysisRequestValidator : AbstractValidator<CreateCephAnalysisRequest>
{
    public CreateCephAnalysisRequestValidator()
    {
        RuleFor(x => x.OrthoCaseId)
            .NotEmpty().WithMessage("رقم حالة التقويم مطلوب");

        RuleFor(x => x.AnalysisType)
            .NotEmpty().WithMessage("نوع التحليل مطلوب")
            // "full" runs every analysis; "wits" is computed by the engine too.
            // These must match the options offered by the frontend new-analysis form.
            .Must(t => t is "full" or "steiner" or "mcnamara" or "downs" or "tweed"
                or "ricketts" or "jarabak" or "wits" or "pa")
            .WithMessage("نوع التحليل غير صالح");

        RuleFor(x => x.XrayFileUrl)
            .MaximumLength(2048).WithMessage("رابط صورة الأشعة طويل جدًا")
            .Must(BeValidXrayUrl).WithMessage("رابط صورة الأشعة غير صالح")
            .When(x => !string.IsNullOrWhiteSpace(x.XrayFileUrl));

        RuleFor(x => x.Notes)
            .MaximumLength(2000).WithMessage("الملاحظات يجب ألا تتجاوز 2000 حرف");
    }

    private static bool BeValidXrayUrl(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return true;

        var url = value.Trim();
        if (url.StartsWith("/uploads/", StringComparison.OrdinalIgnoreCase))
        {
            var fileName = url["/uploads/".Length..];
            return fileName.Length > 0
                && !fileName.Contains('/')
                && !fileName.Contains('\\')
                && !fileName.Contains("..", StringComparison.Ordinal);
        }

        return Uri.TryCreate(url, UriKind.Absolute, out var uri)
            && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
    }
}

public sealed class SaveLandmarksRequestValidator : AbstractValidator<SaveLandmarksRequest>
{
    public SaveLandmarksRequestValidator()
    {
        RuleFor(x => x.Landmarks)
            .NotEmpty().WithMessage("يجب إضافة نقطة مرجعية واحدة على الأقل")
            .Must(items => items.Count <= 100).WithMessage("لا يمكن حفظ أكثر من 100 نقطة مرجعية");

        // 0 = uncalibrated. Angle-only and ratio analyses (e.g. Jarabak's
        // saddle/articular/gonial angles and the S-Go/N-Me facial-height ratio)
        // are scale-independent and must be savable without ruler calibration;
        // the engine simply skips the mm-based measurements when this is 0.
        RuleFor(x => x.PixelsPerMm)
            .GreaterThanOrEqualTo(0).WithMessage("مقياس البكسل لكل ملم يجب ألا يكون سالبًا");

        RuleFor(x => x.ImageWidth)
            .GreaterThan(0).WithMessage("عرض الصورة يجب أن يكون أكبر من صفر");

        RuleFor(x => x.ImageHeight)
            .GreaterThan(0).WithMessage("ارتفاع الصورة يجب أن يكون أكبر من صفر");

        RuleForEach(x => x.Landmarks)
            .ChildRules(landmark =>
            {
                landmark.RuleFor(l => l.Key)
                    .NotEmpty().WithMessage("مفتاح النقطة المرجعية مطلوب")
                    .MaximumLength(100).WithMessage("مفتاح النقطة المرجعية طويل جدًا");
                landmark.RuleFor(l => l.X)
                    .Must(double.IsFinite).WithMessage("الإحداثي الأفقي غير صالح")
                    .GreaterThanOrEqualTo(0).WithMessage("الإحداثي الأفقي يجب أن يكون صفر أو أكبر");
                landmark.RuleFor(l => l.Y)
                    .Must(double.IsFinite).WithMessage("الإحداثي العمودي غير صالح")
                    .GreaterThanOrEqualTo(0).WithMessage("الإحداثي العمودي يجب أن يكون صفر أو أكبر");
                landmark.RuleFor(l => l.Confidence)
                    .Must(value => !value.HasValue || (double.IsFinite(value.Value) && value is >= 0 and <= 1))
                    .WithMessage("ثقة نقطة الذكاء الاصطناعي يجب أن تكون بين صفر وواحد");
                landmark.RuleFor(l => l.Reasoning)
                    .MaximumLength(200).WithMessage("سبب وضع النقطة يجب ألا يتجاوز 200 حرف");
                landmark.RuleFor(l => l.SourceLandmarkKey)
                    .MaximumLength(100).WithMessage("اسم النقطة في المصدر يجب ألا يتجاوز 100 حرف");
                landmark.RuleFor(l => l.SourceModelId)
                    .MaximumLength(100).WithMessage("معرّف نموذج الذكاء الاصطناعي يجب ألا يتجاوز 100 حرف");
                landmark.RuleFor(l => l.PlacementSource)
                    .Must(value => string.IsNullOrWhiteSpace(value)
                        || value is "manual" or "ai" or "webceph-import")
                    .WithMessage("مصدر النقطة غير صالح");
                landmark.RuleFor(l => l)
                    .Must(l => l.AiProposalX.HasValue == l.AiProposalY.HasValue
                        && (!l.AiProposalX.HasValue
                            || (double.IsFinite(l.AiProposalX.Value)
                                && double.IsFinite(l.AiProposalY!.Value))))
                    .WithMessage("يجب إرسال إحداثيي اقتراح الذكاء الاصطناعي معًا وبقيم صالحة");
            });

        RuleFor(x => x).Custom((request, context) =>
        {
            foreach (var landmark in request.Landmarks)
            {
                if (landmark.X > request.ImageWidth || landmark.Y > request.ImageHeight)
                {
                    context.AddFailure(
                        "Landmarks",
                        $"النقطة {landmark.Key} تقع خارج حدود الصورة");
                }
            }
        });
    }
}

public sealed class SaveDiagnosisRequestValidator : AbstractValidator<SaveDiagnosisRequest>
{
    public SaveDiagnosisRequestValidator()
    {
        RuleFor(x => x.SkeletalClass)
            .Must(s => string.IsNullOrEmpty(s) || s is "Class I" or "Class II" or "Class II Division 1"
                or "Class II Division 2" or "Class III")
            .WithMessage("التصنيف الهيكلي غير صالح");

        RuleFor(x => x.FinalDiagnosis)
            .MaximumLength(2000).WithMessage("التشخيص النهائي يجب ألا يتجاوز 2000 حرف");

        RuleFor(x => x.SoftTissueSummary)
            .MaximumLength(2000).WithMessage("ملخص الأنسجة الرخوة يجب ألا يتجاوز 2000 حرف");
    }
}

public sealed class ImportCephAssessmentProblemsRequestValidator
    : AbstractValidator<ImportCephAssessmentProblemsRequest>
{
    private static readonly HashSet<string> AllowedCategories =
        ["skeletal", "dental", "soft_tissue", "functional", "space", "esthetic"];

    private static readonly HashSet<string> AllowedSeverities =
        ["mild", "moderate", "severe"];

    public ImportCephAssessmentProblemsRequestValidator()
    {
        RuleFor(x => x.Items)
            .NotEmpty().WithMessage("اختر عنصراً واحداً على الأقل")
            .Must(items => items is { Count: <= 20 }).WithMessage("لا يمكن نقل أكثر من 20 عنصراً دفعة واحدة");

        RuleForEach(x => x.Items).ChildRules(item =>
        {
            item.RuleFor(x => x.Category)
                .Must(category => AllowedCategories.Contains(category))
                .WithMessage("تصنيف المشكلة غير صالح");
            item.RuleFor(x => x.Description)
                .NotEmpty().WithMessage("وصف المشكلة مطلوب")
                .MaximumLength(500).WithMessage("وصف المشكلة يجب ألا يتجاوز 500 حرف");
            item.RuleFor(x => x.Severity)
                .Must(severity => AllowedSeverities.Contains(severity))
                .WithMessage("شدة المشكلة غير صالحة");
        });
    }
}

public sealed class SaveCephVtoScenarioRequestValidator : AbstractValidator<SaveCephVtoScenarioRequest>
{
    public SaveCephVtoScenarioRequestValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("اسم السيناريو مطلوب")
            .MaximumLength(100).WithMessage("اسم السيناريو يجب ألا يتجاوز 100 حرف");
        RuleFor(x => x.UpperIncisorMoveMm)
            .InclusiveBetween(-8, 8).WithMessage("حركة القاطع العلوي يجب أن تكون بين -8 و8 مم")
            .Must(IsHalfMillimeterStep).WithMessage("حركة القاطع العلوي يجب أن تكون بخطوة 0.5 مم");
        RuleFor(x => x.LowerIncisorMoveMm)
            .InclusiveBetween(-8, 8).WithMessage("حركة القاطع السفلي يجب أن تكون بين -8 و8 مم")
            .Must(IsHalfMillimeterStep).WithMessage("حركة القاطع السفلي يجب أن تكون بخطوة 0.5 مم");
        RuleFor(x => x.Notes)
            .MaximumLength(2000).WithMessage("الملاحظات يجب ألا تتجاوز 2000 حرف");
    }

    private static bool IsHalfMillimeterStep(decimal value) => value * 2 == decimal.Truncate(value * 2);
}

public sealed class SavePhotoAnalysisRequestValidator : AbstractValidator<SavePhotoAnalysisRequest>
{
    public SavePhotoAnalysisRequestValidator()
    {
        RuleFor(x => x.OrthoCaseId)
            .NotEmpty().WithMessage("رقم حالة التقويم مطلوب");

        RuleFor(x => x.ViewType)
            .Must(v => v is "profile" or "frontal")
            .WithMessage("نوع الصورة غير صالح");

        RuleFor(x => x.ImageFileUrl)
            .NotEmpty().WithMessage("صورة التحليل مطلوبة")
            .MaximumLength(1000).WithMessage("رابط الصورة طويل جدًا");

        RuleFor(x => x.Notes)
            .MaximumLength(2000).WithMessage("الملاحظات يجب ألا تتجاوز 2000 حرف");

        RuleFor(x => x.LandmarksJson)
            .MaximumLength(100_000).WithMessage("بيانات المعالم كبيرة جدًا");

        RuleFor(x => x.MeasurementsJson)
            .MaximumLength(100_000).WithMessage("بيانات القياسات كبيرة جدًا");
    }
}

public sealed class AiSimulateRequestValidator : AbstractValidator<AiSimulateRequest>
{
    public AiSimulateRequestValidator()
    {
        RuleFor(x => x.ImageWidth)
            .GreaterThan(0).WithMessage("عرض الصورة يجب أن يكون أكبر من صفر");

        RuleFor(x => x.ImageHeight)
            .GreaterThan(0).WithMessage("ارتفاع الصورة يجب أن يكون أكبر من صفر");

        RuleFor(x => x.PixelsPerMm)
            .GreaterThan(0).WithMessage("مقياس البكسل لكل ملم يجب أن يكون أكبر من صفر");
    }
}
