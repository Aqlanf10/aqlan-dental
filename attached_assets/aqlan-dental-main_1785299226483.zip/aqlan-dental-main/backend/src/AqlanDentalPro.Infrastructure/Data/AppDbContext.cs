using AqlanDentalPro.Domain.Entities;
using AqlanDentalPro.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.Json;

namespace AqlanDentalPro.Infrastructure.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Doctor> Doctors => Set<Doctor>();
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<Patient> Patients => Set<Patient>();
    public DbSet<MedicalHistory> MedicalHistories => Set<MedicalHistory>();
    public DbSet<DentalHistory> DentalHistories => Set<DentalHistory>();
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<Visit> Visits => Set<Visit>();
    public DbSet<OrthoCase> OrthoCases => Set<OrthoCase>();
    public DbSet<OrthoClinicalExam> OrthoClinicalExams => Set<OrthoClinicalExam>();
    public DbSet<ProblemListItem> ProblemListItems => Set<ProblemListItem>();
    public DbSet<TreatmentPlan> TreatmentPlans => Set<TreatmentPlan>();
    public DbSet<OrthoVisit> OrthoVisits => Set<OrthoVisit>();
    public DbSet<TreatmentStage> TreatmentStages => Set<TreatmentStage>();
    public DbSet<RetentionRecord> RetentionRecords => Set<RetentionRecord>();
    public DbSet<RetentionVisit> RetentionVisits => Set<RetentionVisit>();
    public DbSet<CephAnalysis> CephAnalyses => Set<CephAnalysis>();
    public DbSet<CephLandmark> CephLandmarks => Set<CephLandmark>();
    public DbSet<CephMeasurement> CephMeasurements => Set<CephMeasurement>();
    public DbSet<CephDiagnosis> CephDiagnoses => Set<CephDiagnosis>();
    public DbSet<CephNorm> CephNorms => Set<CephNorm>();
    public DbSet<OrthodonticAiLog> OrthodonticAiLogs => Set<OrthodonticAiLog>();
    public DbSet<CephAiModelVersion> CephAiModelVersions => Set<CephAiModelVersion>();
    public DbSet<CephAiModelDeployment> CephAiModelDeployments => Set<CephAiModelDeployment>();
    public DbSet<CephAiInferenceRun> CephAiInferenceRuns => Set<CephAiInferenceRun>();
    // CEPH-EPIC batch C-B — named snapshots of an analysis (landmarks +
    // measurements + diagnosis as JSON) for longitudinal progress tracking.
    public DbSet<CephAnalysisVersion> CephAnalysisVersions => Set<CephAnalysisVersion>();
    public DbSet<CephVtoScenario> CephVtoScenarios => Set<CephVtoScenario>();
    public DbSet<ModelAnalysis> ModelAnalyses => Set<ModelAnalysis>();
    public DbSet<ExtractionDecision> ExtractionDecisions => Set<ExtractionDecision>();
    public DbSet<DentalChart> DentalCharts => Set<DentalChart>();
    public DbSet<ToothCondition> ToothConditions => Set<ToothCondition>();
    public DbSet<GeneralTreatment> GeneralTreatments => Set<GeneralTreatment>();
    public DbSet<PerioAssessment> PerioAssessments => Set<PerioAssessment>();
    public DbSet<SurgeryCase> SurgeryCases => Set<SurgeryCase>();
    public DbSet<PreopReport> PreopReports => Set<PreopReport>();
    public DbSet<OperativeReport> OperativeReports => Set<OperativeReport>();
    public DbSet<PostopRecord> PostopRecords => Set<PostopRecord>();
    public DbSet<HospitalReferral> HospitalReferrals => Set<HospitalReferral>();
    // Ortho-Surgical (orthognathic) planning bridge — shared workflow between ortho & surgery.
    public DbSet<OrthoSurgicalCase> OrthoSurgicalCases => Set<OrthoSurgicalCase>();
    public DbSet<SurgeonReview> SurgeonReviews => Set<SurgeonReview>();
    public DbSet<JointPlan> JointPlans => Set<JointPlan>();
    public DbSet<OrthoSurgicalComment> OrthoSurgicalComments => Set<OrthoSurgicalComment>();
    // Sprint A9 — Surgical VTO (Visual Treatment Objective) scenarios on an Ortho-Surgical case.
    public DbSet<OrthoSurgicalVto> OrthoSurgicalVtos => Set<OrthoSurgicalVto>();
    public DbSet<Contract> Contracts => Set<Contract>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<PaymentAllocation> PaymentAllocations => Set<PaymentAllocation>();
    public DbSet<Receipt> Receipts => Set<Receipt>();
    public DbSet<ClinicalPhoto> ClinicalPhotos => Set<ClinicalPhoto>();
    public DbSet<Radiograph> Radiographs => Set<Radiograph>();
    public DbSet<InternalReferral> InternalReferrals => Set<InternalReferral>();
    public DbSet<Document> Documents => Set<Document>();
    public DbSet<Prescription> Prescriptions => Set<Prescription>();
    public DbSet<RadiologyOrder> RadiologyOrders => Set<RadiologyOrder>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<Setting> Settings => Set<Setting>();
    public DbSet<Inventory> Inventory => Set<Inventory>();
    public DbSet<LabOrder> LabOrders => Set<LabOrder>();
    public DbSet<AiRecommendation> AiRecommendations => Set<AiRecommendation>();
    public DbSet<Conversation> Conversations => Set<Conversation>();
    public DbSet<ConversationParticipant> ConversationParticipants => Set<ConversationParticipant>();
    public DbSet<Message> Messages => Set<Message>();
    public DbSet<MessageRead> MessageReads => Set<MessageRead>();
    public DbSet<MessageAttachment> MessageAttachments => Set<MessageAttachment>();
    public DbSet<PatientAccount> PatientAccounts => Set<PatientAccount>();
    public DbSet<WhatsAppMessage> WhatsAppMessages => Set<WhatsAppMessage>();
    public DbSet<WhatsAppTemplate> WhatsAppTemplates => Set<WhatsAppTemplate>();
    public DbSet<PerioRecord> PerioRecords => Set<PerioRecord>();
    public DbSet<GeneralTreatmentPlanItem> GeneralTreatmentPlanItems => Set<GeneralTreatmentPlanItem>();
    public DbSet<DoctorSchedule> DoctorSchedules => Set<DoctorSchedule>();
    public DbSet<BookingRequest> BookingRequests => Set<BookingRequest>();
    public DbSet<ClinicQueueItem> ClinicQueueItems => Set<ClinicQueueItem>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<ClinicService> ClinicServices => Set<ClinicService>();
    public DbSet<ClinicRoom> ClinicRooms => Set<ClinicRoom>();
    public DbSet<PatientTreatmentPlanStep> PatientTreatmentPlanSteps => Set<PatientTreatmentPlanStep>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<InvoiceLineItem> InvoiceLineItems => Set<InvoiceLineItem>();
    public DbSet<OrthoDiagnosis> OrthoDiagnoses => Set<OrthoDiagnosis>();
    public DbSet<OrthoClinicalPhoto> OrthoClinicalPhotos => Set<OrthoClinicalPhoto>();
    public DbSet<OrthoImagePreparation> OrthoImagePreparations => Set<OrthoImagePreparation>();
    public DbSet<PhotoAnalysis> PhotoAnalyses => Set<PhotoAnalysis>();
    public DbSet<RecordsChecklist> RecordsChecklists => Set<RecordsChecklist>();
    public DbSet<Supplier> Suppliers => Set<Supplier>();
    public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
    public DbSet<PurchaseOrderLineItem> PurchaseOrderLineItems => Set<PurchaseOrderLineItem>();
    public DbSet<InventoryAdjustment> InventoryAdjustments => Set<InventoryAdjustment>();
    public DbSet<DoctorCommissionPayment> DoctorCommissionPayments => Set<DoctorCommissionPayment>();
    public DbSet<PasswordResetRequest> PasswordResetRequests => Set<PasswordResetRequest>();
    public DbSet<PasswordResetToken> PasswordResetTokens => Set<PasswordResetToken>();
    public DbSet<EmailLog> EmailLogs => Set<EmailLog>();
    public DbSet<SmsMessage> SmsMessages => Set<SmsMessage>();
    public DbSet<SmsTemplate> SmsTemplates => Set<SmsTemplate>();

    // Sprint 2 — Payment Method Settings
    public DbSet<PaymentMethodSetting> PaymentMethodSettings => Set<PaymentMethodSetting>();

    // YOLO-S1 — Treatment Packages (catalog for appointment + ortho contracts later)
    public DbSet<TreatmentPackage> TreatmentPackages => Set<TreatmentPackage>();

    // YOLO-S2 — Service catalog bindings:
    //   - TreatmentPackageService: package ↔ service link (Quantity + OverridePrice)
    //   - ServiceConsumable: service ↔ inventory item link (Quantity + Notes)
    public DbSet<TreatmentPackageService> TreatmentPackageServices => Set<TreatmentPackageService>();
    public DbSet<ServiceConsumable> ServiceConsumables => Set<ServiceConsumable>();

    // Lab Sprint 2 — Lab Management Foundation
    public DbSet<Lab> Labs => Set<Lab>();
    public DbSet<LabWorkType> LabWorkTypes => Set<LabWorkType>();

    // Lab Sprint 3 — Professional Orders, Items & Pricing
    public DbSet<LabWorkPrice> LabWorkPrices => Set<LabWorkPrice>();
    public DbSet<LabOrderItem> LabOrderItems => Set<LabOrderItem>();

    // Lab Sprint 4 — Remake, Return, Status History & Attachments
    public DbSet<LabOrderStatusHistory> LabOrderStatusHistories => Set<LabOrderStatusHistory>();
    public DbSet<LabOrderAttachment> LabOrderAttachments => Set<LabOrderAttachment>();

    // Lab Sprint 5 — PDF and Finance Integration
    public DbSet<LabPayable> LabPayables => Set<LabPayable>();

    // Sprint 15 — HR Module
    public DbSet<Attendance> Attendances => Set<Attendance>();
    public DbSet<SalaryRecord> SalaryRecords => Set<SalaryRecord>();
    public DbSet<AdvancePayment> AdvancePayments => Set<AdvancePayment>();
    public DbSet<LeaveRequest> LeaveRequests => Set<LeaveRequest>();
    public DbSet<EmployeeDocument> EmployeeDocuments => Set<EmployeeDocument>();

    // Sprint 18 — Backup
    public DbSet<BackupRecord> BackupRecords => Set<BackupRecord>();

    // Sprint 20 — Finance V2 Comprehensive Hub
    public DbSet<CashierSession> CashierSessions => Set<CashierSession>();
    public DbSet<CashierSessionCurrencyOpeningBalance> CashierSessionCurrencyOpeningBalances => Set<CashierSessionCurrencyOpeningBalance>();
    public DbSet<CashierSessionCurrencyReconciliation> CashierSessionCurrencyReconciliations => Set<CashierSessionCurrencyReconciliation>();
    public DbSet<OperationalExpense> OperationalExpenses => Set<OperationalExpense>();
    public DbSet<CashFlowTransaction> CashFlowTransactions => Set<CashFlowTransaction>();

    // Sprint 21 — Treasuries & Vault Transfers
    public DbSet<Treasury> Treasuries => Set<Treasury>();
    public DbSet<VaultTransfer> VaultTransfers => Set<VaultTransfer>();

    // Sprint 22 — Accounts Payable (Supplier Bills)
    public DbSet<SupplierBill> SupplierBills => Set<SupplierBill>();
    public DbSet<SupplierBillPayment> SupplierBillPayments => Set<SupplierBillPayment>();

    // Finance Phase 1 — Credit Notes & Returns
    public DbSet<CreditNote> CreditNotes => Set<CreditNote>();

    // Finance V3 — Double-Entry Bookkeeping (JournalEntry + JournalLine)
    public DbSet<JournalEntry> JournalEntries => Set<JournalEntry>();
    public DbSet<JournalLine> JournalLines => Set<JournalLine>();
    public DbSet<AccountingPeriod> AccountingPeriods => Set<AccountingPeriod>();

    // YOLO-S5 — Patient Segments (custom manual lists; pre-built dynamic
    // segments are computed in PatientSegmentsController and not stored).
    public DbSet<PatientSegment> PatientSegments => Set<PatientSegment>();
    public DbSet<PatientSegmentMember> PatientSegmentMembers => Set<PatientSegmentMember>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

        // Prevent EF Core from treating System.Text.Json.JsonDocument as an entity type.
        // JsonDocument is only used as a scalar property (serialized to jsonb in PostgreSQL,
        // or to string via ValueConverter in InMemory). Without Ignore, the ConstructorBindingConvention
        // attempts to find a constructor for JsonDocument and fails.
        modelBuilder.Ignore<JsonDocument>();

        // Global value converter for JsonDocument? properties.
        // Npgsql (PostgreSQL) maps JsonDocument → jsonb natively at runtime,
        // but the InMemory provider cannot construct JsonDocument via constructor binding.
        // This explicit converter ensures both providers work: it serializes JsonDocument
        // to its raw JSON text for storage, and parses it back on read.
        // HasColumnType("jsonb") on individual configurations still directs PostgreSQL
        // to store the converted string as a jsonb column.
        var jsonConverter = new ValueConverter<JsonDocument?, string?>(
            v => v == null ? null : v.RootElement.GetRawText(),
            v => string.IsNullOrEmpty(v) ? null : JsonDocument.Parse(v, default));

        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            foreach (var property in entityType.GetProperties()
                         .Where(p => p.ClrType == typeof(JsonDocument) && p.GetValueConverter() == null))
            {
                property.SetValueConverter(jsonConverter);
            }
        }

        // Finance Phase 1: CreditNote, SupplierBill, Supplier configurations
        // are now in dedicated IEntityTypeConfiguration classes:
        // - CreditNoteConfiguration.cs
        // - SupplierBillConfiguration.cs
        // - SupplierConfiguration.cs
        // (Applied automatically via ApplyConfigurationsFromAssembly above)

        // Global soft-delete query filter for all ISoftDeletable entities
        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            if (typeof(ISoftDeletable).IsAssignableFrom(entityType.ClrType))
            {
                var parameter = Expression.Parameter(entityType.ClrType, "e");
                var property = Expression.Property(parameter, nameof(ISoftDeletable.IsActive));
                var filter = Expression.Lambda(property, parameter);
                modelBuilder.Entity(entityType.ClrType).HasQueryFilter(filter);
            }
        }
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        var now = DateTime.UtcNow;
        foreach (var entry in ChangeTracker.Entries<BaseEntity>())
        {
            switch (entry.State)
            {
                case EntityState.Added:
                    entry.Entity.CreatedAt = now;
                    entry.Entity.UpdatedAt = now;
                    break;
                case EntityState.Modified:
                    entry.Entity.UpdatedAt = now;
                    break;
            }
        }
        return await base.SaveChangesAsync(cancellationToken);
    }
}
